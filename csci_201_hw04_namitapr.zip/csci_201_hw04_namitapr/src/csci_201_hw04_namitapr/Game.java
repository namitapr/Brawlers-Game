package csci_201_hw04_namitapr;

import java.util.ArrayList;

public class Game {
	private String name;
	private int numPlayers;
	private ServerThread st1;
	private ServerThread st2;
	
	private ArrayList<Brawler> brawlers; // master list of brawlers
	private ArrayList<BrawlerInfo> brawlerInfo1; // player 1's picks
	private ArrayList<BrawlerInfo> brawlerInfo2; // player 2's picks
	private String currBrawler1;
	private String currBrawler2;
	private String currMove1;
	private String currMove2;
	private ArrayList<Ability> abilities1;
	private ArrayList<Ability> abilities2;
	private Stats stats1;
	private Stats stats2;
	private int br1Health;
	private int br2Health;
	private boolean p1Responded;
	private boolean p2Responded;
	private boolean otherSent;
	private boolean singlePlayer;
	
	private ServerThread lostThread;
	private boolean lost;
	
	public Game(Brawlers b, String name, int numPlayers) {
		this.brawlers = b.getBrawlers();
		this.name = name;
		this.numPlayers = numPlayers;
	
		brawlerInfo1 = new ArrayList<BrawlerInfo>();
		brawlerInfo2 = new ArrayList<BrawlerInfo>();
		abilities1 = new ArrayList<Ability>();
		abilities2 = new ArrayList<Ability>();
		
		currBrawler1 = "";
		currBrawler2 = "";
		currMove1 = "";
		currMove2 = "";
		
		br1Health = 0;
		br2Health = 0;
		
		p1Responded = false;
		p2Responded = false;
		otherSent = false;
		
		if(numPlayers < 2) {
			singlePlayer = true;
		}
		else {
			singlePlayer = false;
		}
		
		lostThread = null;
		lost = false;
	}
	
	// methods for setting up game
	public boolean isFull() {
		if(numPlayers == 1) {
			// max 1 player only
			if(st1 == null) {
				return false;
			}
			return true;
		}
		else {
			// max 2 players
			if(st1 == null || st2 == null) {
				return false;
			}
			return true;
		}
	}
	
	public void addConnection(ServerThread st) {
		if(st1 == null) {
			this.st1 = st;
		}
		else if (st2 == null) {
			this.st2 = st;
		}
	}
	
	public ServerThread getST1() {
		return this.st1;
	}
	
	public ServerThread getST2() {
		return this.st2;
	}
	
	// methods for actual gameplay
	private boolean manageResponses(ServerThread st) {
		if(p1Responded && p2Responded) {
			p1Responded = false;
			p2Responded = false;
		}
		
		if(st == st1) {
			p1Responded = true;
		}
		else {
			p2Responded = true;
		}
		
		return p1Responded && p2Responded;
	}
	
	public String displayBrawlers(ServerThread st) {
		// testing print
		// System.out.println("displayBrawlers called");
		
		String message = "";
		
		message += "Choose 3 Brawlers:\n";
		int i=1;
		for(Brawler b: brawlers) {
			message += i + ") " + b.getName() + "\n";
			i++;
		}
		
		// testing print
		// System.out.println("final message from displayBrawlers: " + message);
		
		return message;
	}
	
	public void generateComputerInputs() {
		for(int i=0; i<brawlers.size(); i++) {
			brawlerInfo2.add(new BrawlerInfo(i, true));
		}
	}
	
	public String setBrawlers(ServerThread st, int b1, int b2, int b3) {
		
		if(b1 > brawlers.size()-1 || b2 > brawlers.size()-1  || b3 > brawlers.size()-1
				|| b1 < 0 ||  b2 < 0 ||  b3 < 0 ) {
			return "Invalid!";
		}
		else {
			if(st == st1) {
				brawlerInfo1.add(new BrawlerInfo(b1, true));
				brawlerInfo1.add(new BrawlerInfo(b2, true));
				brawlerInfo1.add(new BrawlerInfo(b3, true));
			}
			else if (st == st2) {
				brawlerInfo2.add(new BrawlerInfo(b1, true));
				brawlerInfo2.add(new BrawlerInfo(b2, true));
				brawlerInfo2.add(new BrawlerInfo(b3, true));
			}
			return "Excellent!";
		}
	}
	
	public String sendBrawler(ServerThread st) {		
		int ind = -1;
		if(st == st1) {
			for(BrawlerInfo b: brawlerInfo1) {
				if(b.isAlive()) {
					ind = b.getInd();
					break;
				}
			}
			
			Brawler br = brawlers.get(ind);
			currBrawler1 = br.getName();
			abilities1 = br.getAbilities();
			stats1 = br.getStats();
			br1Health = stats1.getHealth();			
		}
		else if (st == st2) {
			for(BrawlerInfo b: brawlerInfo2) {
				if(b.isAlive()) {
					ind = b.getInd();
					break;
				}
			}
			
			Brawler br = brawlers.get(ind);
			currBrawler2 = br.getName();
			abilities2 = br.getAbilities();
			stats2 = br.getStats();
			br2Health = stats2.getHealth();
		}
		
		int ind1 = -1;
		if (singlePlayer) {
			for(BrawlerInfo b: brawlerInfo2) {
				if(b.isAlive()) {
					ind1 = b.getInd();
					break;
				}
			}
			
			Brawler br = brawlers.get(ind1);
			currBrawler2 = br.getName();
			abilities2 = br.getAbilities();
			stats2 = br.getStats();
			br2Health = stats2.getHealth();
		}
		
		if(ind < 0) {
			return "You are out of brawlers!";
		}
	
		String result = "You send " + brawlers.get(ind).getName() + "!\n";
		return result;
	}
	
	public String sendNewBrawler(ServerThread st) {
		otherSent = true;
		
		int ind = -1;
		if(st == st1) {
			for(BrawlerInfo b: brawlerInfo1) {
				if(b.isAlive()) {
					ind = b.getInd();
					break;
				}
			}
			
			if(ind < 0) {
				return "You are out of brawlers!";
			}
			
			Brawler br = brawlers.get(ind);
			currBrawler1 = br.getName();
			abilities1 = br.getAbilities();
			stats1 = br.getStats();
			br1Health = stats1.getHealth();
		}
		else if (st == st2) {
			for(BrawlerInfo b: brawlerInfo2) {
				if(b.isAlive()) {
					ind = b.getInd();
					break;
				}
			}
			
			if(ind < 0) {
				return "You are out of brawlers!";
			}
			
			Brawler br = brawlers.get(ind);
			currBrawler2 = br.getName();
			abilities2 = br.getAbilities();
			stats2 = br.getStats();
			br2Health = stats2.getHealth();
		}
		
		int ind1 = -1;
		if(singlePlayer) {
			for(BrawlerInfo b: brawlerInfo2) {
				if(b.isAlive()) {
					ind1 = b.getInd();
					break;
				}
			}
			
			Brawler br = brawlers.get(ind1);
			currBrawler2 = br.getName();
			abilities2 = br.getAbilities();
			stats2 = br.getStats();
			br2Health = stats2.getHealth();
		}
	
		String result = "You send " + brawlers.get(ind).getName() + "!\n";
		return result;
	}
	
	public String getOpponentBrawler(ServerThread st) {
		if(currBrawler1.equals("") || currBrawler2.equals("")) {
			return "";
		}
				
		if(st1 == st) {
			return "Your opponent plays " + currBrawler2 + "!\n";
		}
		else if (st2 == st) {
			return "Your opponent plays " + currBrawler1 + "!\n";
		}
		else {
			return "";
		}
	}
	
	public String getNewOpponentBrawler(ServerThread st) {
		if(lost && (st != lostThread)) {
			return "Your opponent is out of brawlers!\n\nYou Win!";
		}
		
		if(!otherSent) {
			return "";
		}
		
		otherSent = false;
		if(st1 == st) {
			return "Your opponent plays " + currBrawler2 + "!\n";
		}
		else if (st2 == st) {
			return "Your opponent plays " + currBrawler1 + "!\n";
		}
		else {
			return "";
		}
	}
	
	public String chooseMove(ServerThread st) {
		if(!currMove1.equals("") && !currMove2.equals("")) {
			currMove1 = "";
			currMove2 = "";
		}
		
		String message = "Choose a move:\n";
		
		int i=1;
		if(st == st1) {
			for(Ability a: abilities1) {
				message += i + ") " + a.getName() + ", " + a.getType() + ", " + a.getDamage() + "\n";
				i++;
			}
		}
		
		else if (st == st2) {
			for(Ability a: abilities2) {
				message += i + ") " + a.getName() + ", " + a.getType() + ", " + a.getDamage() + "\n";
				i++;
			}
		}
		
		return message;
	}
	
	public void setCurrMove(ServerThread st, int currMove) {
		if(st == st1) {
			currMove1 = abilities1.get(currMove-1).getName();
		}
		else if (st == st2) {
			currMove2 = abilities2.get(currMove-1).getName();
		}
		if(singlePlayer) {
			currMove2 = abilities2.get(currMove-1).getName();
		}
	}
	
	public String displayPlay(ServerThread st) {
		String message = "";
		
		if(currMove1.equals("") || currMove2.equals("")) {
			return "";
		}
		
		calcHealth(1);
		calcHealth(2);

		if(stats1.getSpeed() < stats2.getSpeed()) {
			// player 2's brawler goes first
			message += currBrawler2 + " used " + currMove2 + "!\n";
			message += typeEffectiveness(2);
			message += "It did " + calcDamage(2) + " damage!\n";
			if(br1Health < 1) {
				// player 1's brawler was defeated
				message += "\n" + currBrawler1 + " was defeated!\n";
				return message;
			}
			
			message += currBrawler1 + " used " + currMove1 + "!\n";
			message += typeEffectiveness(1);
			message += "It did " + calcDamage(1) + " damage!\n";
			if (br2Health < 1) {
				// player 2's brawler was defeated
				message += "\n" + currBrawler2 + " was defeated!\n";
				return message;
			}
		}
		else {
			// player 1's brawler goes first
			message += currBrawler1 + " used " + currMove1 + "!\n";
			message += typeEffectiveness(1);
			message += "It did " + calcDamage(1) + " damage!\n";
			if (br2Health < 1) {
				// player 2's brawler was defeated
				message += "\n" + currBrawler2 + " was defeated!\n";
				return message;
			}
			
			message += currBrawler2 + " used " + currMove2 + "!\n";
			message += typeEffectiveness(2);
			message += "It did " + calcDamage(2) + " damage!\n";
			if(br1Health < 1) {
				// player 1's brawler was defeated
				message += "\n" + currBrawler1 + " was defeated!\n";
				return message;
			}	
		}
		
		if(st == st1) {
			message += "\n" + currBrawler1 + " has " + br1Health + " health.\n";
		}
		else {
			message += "\n" + currBrawler2 + " has " + br2Health + " health.\n";
		}
		
		return message;
	}
	
	private String typeEffectiveness(int n) {
		String type1 = "";
		String type2 = "";
		
		if (n == 1) {
			// comparing player1 move type to player2 brawler type
			for(Ability a: abilities1) {
				if(currMove1.equals(a.getName())) {
					type1 = a.getType();
				}
			}
			
			for(Brawler b: brawlers) {
				if(currBrawler2.equals(b.getName())) {
					type2 = b.getType();
				}
			}
			
			if((type1.equals("water") && type2.equals("fire")) || (type1.equals("fire") && type2.equals("air"))
					|| (type1.equals("air") && type2.equals("earth")) || (type1.equals("earth") && type2.equals("lightning"))
							|| (type1.equals("lightning") && type2.equals("water")) ) {
				return "It was super effective!\n";
			}
			if((type1.equals("water")&&type2.equals("lightning")) || (type1.equals("lightning") && type2.equals("earth"))
					|| (type1.equals("earth") && type2.equals("air")) || (type1.equals("air") && type2.equals("fire")) || (type1.equals("fire") && type2.equals("water" ))) {
				return "It was not very effective!\n";
			}
		}
		
		else {
			for(Ability a: abilities2) {
				if(currMove2.equals(a.getName())) {
					type2 = a.getType();
				}
			}
			
			for(Brawler b: brawlers) {
				if(currBrawler1.equals(b.getName())) {
					type1 = b.getType();
				}
			}
			
			if((type2.equals("water") && type1.equals("fire")) || (type2.equals("fire") && type1.equals("air"))
					|| (type2.equals("air") && type1.equals("earth")) || (type2.equals("earth") && type1.equals("lightning"))
							|| (type2.equals("lightning") && type1.equals("water")) ) {
				return "It was super effective!\n";
			}
			if((type2.equals("water")&&type1.equals("lightning")) || (type2.equals("lightning") && type1.equals("earth"))
					|| (type2.equals("earth") && type1.equals("air")) || (type2.equals("air") && type1.equals("fire")) || (type2.equals("fire") && type1.equals("water" ))) {
				return "It was not very effective!\n";
			}
		}
		
		return "";
	}
	
	private int calcDamage(int n) {
		int damage = 0;
		double attack = 0, dam = 0, defense = 0;
		double effect = 1;
		
		if(n == 1) {
			attack = stats1.getAttack();
			defense = stats2.getDefense();
			for(Ability a: abilities1) {
				if(currMove1.equals(a.getName())) {
					dam = a.getDamage();
				}
			}
			if(typeEffectiveness(1).equals("It was super effective!\n")) {
				effect = 2;
			}
			else if (typeEffectiveness(1).equals("It was not very effective!\n")) {
				effect = 0.5;
			}
		}
		else {
			attack = stats2.getAttack();
			defense = stats1.getDefense();
			for(Ability a: abilities2) {
				if(currMove2.equals(a.getName())) {
					dam = a.getDamage();
				}
			}
			if(typeEffectiveness(2).equals("It was super effective!\n")) {
				effect = 2;
			}
			else if (typeEffectiveness(2).equals("It was not very effective!\n")) {
				effect = 0.5;
			}
		}
		
		damage =  (int) Math.floor(((attack*(dam/defense))/5)*(effect));
		return damage;
	}
	
	private void calcHealth(int n) {
		if(n == 1) {
			br1Health -= calcDamage(2);
			
			if(br1Health < 1) {
				// brawler is out of health
				int ind = 0;
				for(Brawler b: brawlers) {
					if(currBrawler1.equals(b.getName())) {
						break;
					}
					ind++;
				}
				for(BrawlerInfo bi: brawlerInfo1) {
					if(bi.getInd() == ind) {
						bi.setAlive(false);
					}
				}
			}
		}
		
		else {
			br2Health -= calcDamage(1);
			
			if(br2Health < 1) {
				// brawler is out of health
				int ind = 0;
				for(Brawler b: brawlers) {
					if(currBrawler2.equals(b.getName())) {
						break;
					}
					ind++;
				}
				for(BrawlerInfo bi: brawlerInfo2) {
					if(bi.getInd() == ind) {
						bi.setAlive(false);
					}
				}
			}
		}
	}
	
	public String checkBrawlerStatus(ServerThread st) {
		if(st == st1) {
			int ind = 0;
			for(Brawler b: brawlers) {
				if(currBrawler1.equals(b.getName())) {
					break;
				}
				ind++;
			}
			for(BrawlerInfo bi: brawlerInfo1) {
				if(bi.getInd() == ind) {
					if(!bi.isAlive()) {
						return "";
					}
					else {
						return "Brawler is still alive!";
					}
				}
			}
		}
		else {
			int ind = 0;
			for(Brawler b: brawlers) {
				if(currBrawler2.equals(b.getName())) {
					break;
				}
				ind++;
			}
			for(BrawlerInfo bi: brawlerInfo2) {
				if(bi.getInd() == ind) {
					if(!bi.isAlive()) {return "";
					}
					else {
						return "Brawler is still alive!";
					}
				}
			}
		}
		if(singlePlayer) {
			int ind = 0;
			for(Brawler b: brawlers) {
				if(currBrawler2.equals(b.getName())) {
					break;
				}
				ind++;
			}
			for(BrawlerInfo bi: brawlerInfo2) {
				if(bi.getInd() == ind) {
					if(!bi.isAlive()) {
						return "";
					}
					else {
						return "Brawler is still alive!";
					}
				}
			}
		}
		
		return "";
	}
	
	// various getter functions
	public String getName() {
		return this.name;
	}
	
	public void setLost(ServerThread st, boolean lost) {
		lostThread = st;
		lost = true;
	}
	
}
