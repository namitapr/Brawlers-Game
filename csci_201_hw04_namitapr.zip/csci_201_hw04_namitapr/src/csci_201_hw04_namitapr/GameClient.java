package csci_201_hw04_namitapr;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class GameClient extends Thread {
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	
	public GameClient(String hostname, int port) {
		try {
			Socket s = new Socket(hostname, port);
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			this.start();
			
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Please make a choice:");
			System.out.println("1) Start Game");
			System.out.println("2) Join Game");
			int option = sc.nextInt();			
			gameSetup(option);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendMessage(GameMessage gm) {
		try {
			oos.writeObject(gm);
			oos.flush();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void gameSetup(int option) {
		Scanner sc = new Scanner(System.in);
		boolean isNewGame;
		if(option == 1) {
			System.out.println("What will you name your game?");
			isNewGame = true;
		}
		else {
			System.out.println("Enter the name of the game you want to join.");
			isNewGame = false;
		}
		String line = sc.nextLine();
		
		// testing print
		// System.out.println("You have entered: " + line);
		
		GameMessage m = new GameMessage(line);
		m.setAction("setup");
		m.setNewGame(isNewGame);
		sendMessage(m);
	}
	
	public void run() {
		try {
			while(true) {
				GameMessage m = (GameMessage)ois.readObject();
				String action = m.getAction();
				if (action.equals("setup")) {
					System.out.println(m.getMessage());
					if(m.getNumPlayers() < 2) {
						m.setAction("displayBrawlers");
						sendMessage(m);
					}
				}
				else if (action.equals("gameExistsError")) {
					System.out.println(m.getMessage());
					int option = 0;
					if(m.getNewGame()) {
						option = 1;
					}
					gameSetup(option);
				}
				else if (action.equals("gameBuilder")) {
					// testing print
					// System.out.println("gameBuilder block entered");
					
					Scanner sc = new Scanner(System.in);
					System.out.println("How many players?");
					System.out.println("1 or 2");
					int numPlayers = sc.nextInt();
					m.setNumPlayers(numPlayers);
					m.setAction("setup");
					sendMessage(m);
				}
				else if (action.equals("displayBrawlers")) {
					// testing print
					// System.out.println("displayBrawlers block entered");
					
					System.out.println(m.getMessage());
					sendMessage(m);
				}
				else if (action.equals("pickBrawlers")) {
					// testing print
					// System.out.println("pickBrawlers block entered");
					
					Scanner sc = new Scanner(System.in);
					System.out.println(m.getMessage());
					int b1, b2, b3;
					b1 = sc.nextInt()-1;
					b2 = sc.nextInt()-1;
					b3 = sc.nextInt()-1;
					
					m.setB1(b1);
					m.setB2(b2);
					m.setB3(b3);
					
					sendMessage(m);
				}
				else if (action.equals("sendBrawler")) {
					// testing print
					// System.out.println("sendBrawler block entered");
					// System.out.println("Excellent!");
					
					System.out.println(m.getMessage());

					if(!m.getMessage().equals("Excellent!")) {
						m.setAction("getOpponentBrawler");
					}
					
					sendMessage(m);
				}
				else if (action.equals("endGameLoss")) {
					System.out.println("You are out of brawlers!\n");
					System.out.println("You Lose!");
				}
				else if (action.equals("getOpponentBrawler")) {
					if(!m.getMessage().equals("")) {
						System.out.println(m.getMessage());
						m.setAction("chooseMove");
					}
					sendMessage(m);
				}
				else if (action.equals("chooseMove")) {
						System.out.println(m.getMessage());
						Scanner sc = new Scanner(System.in);
						int option = sc.nextInt();
						m.setCurrMove(option);
						m.setAction("displayPlay");
						sendMessage(m);
				}
				else if (action.equals("displayPlay")) {					
					if(!m.getMessage().equals("")) {
						System.out.println(m.getMessage());
						if(!m.getMessage().contains("defeated")) {
							m.setAction("chooseMove");
						}
						else {
							m.setAction("checkBrawlerStatus");
						}
					}
					sendMessage(m);
				}
				else if (action.equals("sendNewBrawler")) {
					String message = m.getMessage();
					if(message.contains("You send ")) {
						m.setAction("chooseMove");
					}
					System.out.println(message);
					sendMessage(m);
				}
				else if (action.equals("getNewOpponentBrawler")) {
					if(!m.getMessage().equals("")) {
						System.out.println(m.getMessage());
						m.setAction("chooseMove");
					}
					sendMessage(m);
				}
//				else if (action.equals("singleDisplayBrawlers")) {
//					System.out.println(m.getMessage());
//					Scanner sc = new Scanner(System.in);
//					int b1, b2, b3;
//					b1 = sc.nextInt()-1;
//					b2 = sc.nextInt()-1;
//					b3 = sc.nextInt()-1;
//					m.setB1(b1);
//					m.setB2(b2);
//					m.setB3(b3);
//					
//					m.setAction("singlePickBrawlers");
//					sendMessage(m);
//				}
//				else if (action.equals("singleSendBrawler")) {
//					System.out.println(m.getMessage());
//
//					if(!m.getMessage().equals("Excellent!")) {
//						m.setAction("getOpponentBrawler");
//					}
//					
//					sendMessage(m);
//				}
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter an IP address:");
		String hostname = sc.nextLine();
		// TODO error checking for improper hostname
		
		System.out.println("Please enter a port:");
		int port = sc.nextInt();
		while(port < 1024) {
			System.out.println("Invalid Port!");
			System.out.println("Please enter a valid port:");
			port = sc.nextInt();
		}
		
		GameClient gc = new GameClient(hostname, port);
	}
}
