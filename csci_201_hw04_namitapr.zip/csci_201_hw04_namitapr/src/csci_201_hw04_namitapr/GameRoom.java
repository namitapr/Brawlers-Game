package csci_201_hw04_namitapr;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;

public class GameRoom {
	private Vector<ServerThread> serverThreads;
	private Vector<Game> games;
	private Brawlers b;
	public GameRoom(String filename, int port) {
		try {
			// reading in JSON file
			JsonReader j = new JsonReader(filename);
			this.b = j.getBrawlers();
			
			// binding to port
			ServerSocket ss = new ServerSocket(port);
			
			// initializing vectors
			serverThreads = new Vector<ServerThread>();
			games = new Vector<Game>();
			
			// accepting new connections
			while(true) {
				Socket s = ss.accept();
				ServerThread st = new ServerThread(s, this);
				serverThreads.add(st);
			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	
	public Brawlers getBrawlers() {
		return this.b;
	}
	

	
	// returns true if game does already exist
	public boolean checkGame(String gameName) {
//		// testing print
//		System.out.println("checkGame called on " + gameName);
		
		for(Game g: games) {
			if(gameName.equals(g.getName())) {
				return true;
			}
		}
		
		return false;
	}
	
	// lets a second player join an existing game
	public String joinGame(String gameName, ServerThread st) {
//		// testing print
//		System.out.println("joinGame called on " + gameName);
//		
		String message = "";
		for(Game g: games) {
			if(gameName.equals(g.getName())) {
				if(!g.isFull()) {
					g.addConnection(st);
					message += "Starting game...";
					
					ServerThread st1 = g.getST1();
					GameMessage gMessage = new GameMessage(g.getName());
					gMessage.setAction("displayBrawlers");
					gMessage.setMessage("Player 2 connected\nStarting game...");
					st1.sendMessage(gMessage);
					return message;
				}
				else {
					return "Error! Game is already full.";
				}
			}
		}
		return "Error! Game not found.";
	}
	
	// lets the first player create a game
	public String startGame(String gameName, int numPlayers, ServerThread st) {
//		// testing print
//		System.out.println("startGame called on " + gameName);
		
		String message = "";
		
		Game g = new Game(b, gameName, numPlayers);
		g.addConnection(st);
		games.addElement(g);
		
		if(numPlayers == 2) {
			message += "Waiting for players to connect...";
			return message;
		}
		else {
			message += "Starting game...";
			return message;
		}
	}
	
	public Game getGame(ServerThread st) {
		for(Game g: games) {
			if(g.getST1() == st || g.getST2() == st) {
				return g;
			}
		}
		return null;
	}
	
	public static void main(String [] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Please enter a valid file:");
		String filename = sc.nextLine();
		System.out.println("Please enter a valid port:");
		int port = sc.nextInt();
		while(port < 1024) {
			System.out.println("Invalid Port!");
			System.out.println("Please enter a valid port:");
			port = sc.nextInt();
		}
		System.out.println("Success!");
		GameRoom sm = new GameRoom(filename, port);
	}
}
