package csci_201_hw04_namitapr;

public class Ability {
	private String name;
	private String type;
	private int damage;
	public Ability(String name, String type, int damage) {
		super();
		this.name = name;
		this.type = type;
		this.damage = damage;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		this.damage = damage;
	}
}
