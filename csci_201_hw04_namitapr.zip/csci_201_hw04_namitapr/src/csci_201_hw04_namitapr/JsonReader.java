package csci_201_hw04_namitapr;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class JsonReader {
	private Brawlers b;
	public JsonReader(String filename) throws FileNotFoundException {
		BufferedReader reader = new BufferedReader(new FileReader(filename));
		Gson gson = new GsonBuilder().create();
		b = gson.fromJson(reader, Brawlers.class);
	}
	public Brawlers getBrawlers() {
		return this.b;
	}
}
