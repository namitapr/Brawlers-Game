package csci_201_hw04_namitapr;

import java.io.Serializable;
import java.util.ArrayList;

public class GameMessage implements Serializable {
	public static final long serialVersionUID = 1;
	private String action;
	private boolean newGame;
	private String gameName;
	private int numPlayers;
	private String message;
	private int currMove;
	private int b1;
	private int b2;
	private int b3;
	
	public int getB1() {
		return b1;
	}
	public void setB1(int b1) {
		this.b1 = b1;
	}
	public int getB2() {
		return b2;
	}
	public void setB2(int b2) {
		this.b2 = b2;
	}
	public int getB3() {
		return b3;
	}
	public void setB3(int b3) {
		this.b3 = b3;
	}
	public GameMessage(String gameName) {
		this.action = "setup";
		this.gameName = gameName;
		this.numPlayers = -1;
	}
	public void setNewGame(boolean newGame) {
		this.newGame = newGame;
	}
	public boolean getNewGame() {
		return newGame;
	}
	public String getGameName() {
		return gameName;
	}
	public void setNumPlayers(int numPlayers) {
		this.numPlayers = numPlayers;
	}
	public int getNumPlayers() {
		return this.numPlayers;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMessage() {
		return this.message;
	}
	public void setCurrMove(int currMove) {
		this.currMove = currMove;
	}
	public int getCurrMove() {
		return this.currMove;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getAction() {
		return this.action;
	}
}
