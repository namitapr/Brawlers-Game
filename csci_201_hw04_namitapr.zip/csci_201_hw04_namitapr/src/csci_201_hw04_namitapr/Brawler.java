package csci_201_hw04_namitapr;

import java.util.ArrayList;

public class Brawler {
	private String name;
	private String type;
	private Stats stats;
	private ArrayList<Ability> abilities;
	public Brawler(String name, String type, Stats stats, ArrayList<Ability> abilities) {
		super();
		this.name = name;
		this.type = type;
		this.stats = stats;
		this.abilities = abilities;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Stats getStats() {
		return stats;
	}
	public void setStats(Stats stats) {
		this.stats = stats;
	}
	public ArrayList<Ability> getAbilities() {
		return abilities;
	}
	public void setAbilities(ArrayList<Ability> abilities) {
		this.abilities = abilities;
	}
	
	
	
}
