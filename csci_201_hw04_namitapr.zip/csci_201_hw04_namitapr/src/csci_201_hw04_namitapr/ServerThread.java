package csci_201_hw04_namitapr;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ServerThread extends Thread {
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private GameRoom gr;
	private Game g;
	
	public ServerThread(Socket s, GameRoom gr) {
		try {
			this.gr = gr;
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void sendMessage(GameMessage gm) {
		try {
			oos.writeObject(gm);
			oos.flush();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		try {
			while(true) {
				GameMessage gm = (GameMessage)ois.readObject();
				String action = gm.getAction();
				
				if(action.equals("setup")) {
					boolean newGame = gm.getNewGame();
					String gameName = gm.getGameName();
					boolean gameExists = gr.checkGame(gameName);
					
					// testing print
//					System.out.println("newGame: " + newGame);
//					System.out.println("gameName: " + gameName);
//					System.out.println("gameExists: " + gameExists);
					
					if(newGame && gameExists) {
						// client is trying to create a game that already exists 
						gm.setAction("gameExistsError");
						gm.setMessage("This game already exists!");
						sendMessage(gm);
					}
					else if (!newGame && !gameExists) {
						gm.setAction("gameExistsError");
						gm.setMessage("The game you want to join does not exist!");
						sendMessage(gm);
					}
					else if(!newGame && gameExists) {
						// client wants to join existing game and the game exists
						String message = gr.joinGame(gameName, this);
						gm.setAction("displayBrawlers");
						gm.setMessage(message);
						sendMessage(gm);
					}
					else if(newGame && !gameExists) {
						// client wants to start a new game and the game does not already exists
						if(gm.getNumPlayers()<0) {
							// client hasn't entered numPlayers yet
							
							// testing print
							// System.out.println("numPlayers < 0");
							
							
							gm.setAction("gameBuilder"); 
							sendMessage(gm);
						}
						else {
							// client has entered numPlayers
							String message = gr.startGame(gameName, gm.getNumPlayers(), this);
							g = gr.getGame(this);
							
							if(gm.getNumPlayers() < 2) {
								g.generateComputerInputs();
							}
							
							gm.setMessage(message);
							sendMessage(gm);
						}
					}
				}
				else if (action.equals("displayBrawlers")) {
					// testing print
					// System.out.println("displayBrawlers block entered");
					g = gr.getGame(this);
					String message = g.displayBrawlers(this);
					gm.setAction("pickBrawlers");
					gm.setMessage(message);
					sendMessage(gm);
				}
				else if (action.equals("pickBrawlers")) {
					// testing print
					// System.out.println("pickBrawlers block entered");
					
					int b1 = gm.getB1();
					int b2 = gm.getB2();
					int b3 = gm.getB3();
					String result = g.setBrawlers(this, b1, b2, b3);
					gm.setMessage(result);
					if(result.equals("Invalid!")) {
						gm.setAction("displayBrawlers");
					}
					else {
						gm.setAction("sendBrawler");
					}
					sendMessage(gm);
				}
				else if (action.equals("sendBrawler")) {
					// testing print
					// System.out.println("sendBrawler block entered");
					
					String result = g.sendBrawler(this);
					gm.setMessage(result);
					if(result.equals("You are out of brawlers!")) {
						// client is out of brawlers
						gm.setAction("endGameLoss");
					}
					sendMessage(gm);
				}
				else if (action.equals("getOpponentBrawler")) {
					String message = g.getOpponentBrawler(this);
					gm.setMessage(message);
					sendMessage(gm);
				}
				else if (action.equals("chooseMove")) {
					String message = g.chooseMove(this);
					gm.setMessage(message);
					sendMessage(gm);
				}
				else if (action.equals("displayPlay")) {
					g.setCurrMove(this, gm.getCurrMove());
					String message = g.displayPlay(this);
					gm.setMessage(message);
					sendMessage(gm);
				}
				else if (action.equals("checkBrawlerStatus")) {
					String message = g.checkBrawlerStatus(this);
					gm.setMessage("");
					if(message.equals("")) {
						gm.setAction("sendNewBrawler");
					}
					else {
						gm.setAction("getNewOpponentBrawler");
					}
					sendMessage(gm);
				}
				else if(action.equals("sendNewBrawler")) {					
					String message = g.sendNewBrawler(this);
					
					if(message.contains("You are out of brawlers!")) {
						// client is out of brawlers
						gm.setAction("endGameLoss");
					}
					
					gm.setMessage(message);
					sendMessage(gm);
				}
				else if(action.equals("getNewOpponentBrawler")) {
					String message = g.getNewOpponentBrawler(this);
					
					if(message.contains("Your opponent is out of brawlers!")) {
						gm.setAction("endGameWin");
					}
					
					gm.setMessage(message);
					sendMessage(gm);
				}
//				else if(action.equals("singleDisplayBrawlers")) {
//					gm.setMessage(g.displayBrawlers(this));
//					sendMessage(gm);
//				}
//				else if(action.equals("singlePickBrawlers")) {
//					int b1 = gm.getB1();
//					int b2 = gm.getB2();
//					int b3 = gm.getB3();
//					String result = g.setBrawlers(this, b1, b2, b3);
//					gm.setMessage(result);
//					if(result.equals("Invalid!")) {
//						gm.setAction("singleDisplayBrawlers");
//					}
//					else {
//						gm.setAction("singleSendBrawler");
//					}
//					sendMessage(gm);
//				}
//				else if(action.equals("singleSendBrawler")) {
//					String result = g.sendBrawler(this);
//					gm.setMessage(result);
//					if(result.equals("You are out of brawlers!")) {
//						// client is out of brawlers
//						gm.setAction("endGameLoss");
//					}
//					sendMessage(gm);
//				}
				else if(action.equals("endGameLoss")) {
					g.setLost(this, true);
				}
				
			}
		}
		catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
