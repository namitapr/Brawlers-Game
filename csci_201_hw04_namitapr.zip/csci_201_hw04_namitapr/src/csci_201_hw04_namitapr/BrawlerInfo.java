package csci_201_hw04_namitapr;

public class BrawlerInfo {
	private int ind;
	private boolean alive;
	public BrawlerInfo(int ind, boolean alive) {
		super();
		this.ind = ind; // index of brawler in universal brawler array list
		this.alive = alive;
	}
	public int getInd() {
		return ind;
	}
	public void setInd(int ind) {
		this.ind = ind;
	}
	public boolean isAlive() {
		return alive;
	}
	public void setAlive(boolean alive) {
		this.alive = alive;
	}
}
