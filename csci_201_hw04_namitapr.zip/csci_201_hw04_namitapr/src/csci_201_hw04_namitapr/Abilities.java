package csci_201_hw04_namitapr;
import java.util.ArrayList;

public class Abilities {
	private ArrayList<Ability> abilities;
	
	public Abilities() {
		abilities = new ArrayList<Ability>();
	}
	
	public ArrayList<Ability> getAbilities() {
		return this.abilities;
	}
}
