package csci_201_hw04_namitapr;

import java.util.ArrayList;

public class Brawlers {
	private ArrayList<Brawler> Brawlers;
	
	public Brawlers() {
		Brawlers = new ArrayList<Brawler>();
	}
	
	public ArrayList<Brawler> getBrawlers() {
		return this.Brawlers;
	}
}
